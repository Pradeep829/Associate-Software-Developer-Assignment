import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'; // Make sure BrowserRouter wraps everything
import Homepage from './components/Homepage/Homepage'; // Import Homepage
import UserRegistration from './components/UserRegistration/UserRegistration'; // Example of another route
import "./App.css"
const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<UserRegistration />} />
        {/* Make sure to use * for nested routes */}
        <Route path="/homepage/*" element={<Homepage />} />
      </Routes>
    </Router>
  );
};

export default App;
