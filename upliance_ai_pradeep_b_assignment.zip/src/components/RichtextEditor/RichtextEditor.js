import React, { useState, useEffect } from 'react';
import { Editor, EditorState, RichUtils, convertToRaw, convertFromRaw } from 'draft-js';
import { Button } from '@mui/material';
import 'draft-js/dist/Draft.css';
import Styles from "./richtexteditor.module.css";
import "./richtextEditor.css"
const RichTextEditor = () => {
  const [editorState, setEditorState] = useState(EditorState.createEmpty());
  const [savedData, setSavedData] = useState('');
  const [displayedData, setDisplayedData] = useState('');

  // Load saved content from localStorage (if any)
  useEffect(() => {
    const savedEditorData = localStorage.getItem('richTextData');
    if (savedEditorData) {
      try {
        const contentState = convertFromRaw(JSON.parse(savedEditorData));
        setEditorState(EditorState.createWithContent(contentState));
        console.log("Loaded saved data:", contentState);
      } catch (error) {
        console.error("Error loading saved data:", error);
      }
    }
  }, []);

  const handleEditorChange = (state) => {
    setEditorState(state);
  };

  const handleSave = () => {
    const contentState = editorState.getCurrentContent();
    const rawContent = convertToRaw(contentState);
    localStorage.setItem('richTextData', JSON.stringify(rawContent));
    setSavedData('Data saved!');
    console.log("Saved content:", rawContent); // Debugging line to check saved data
    
    // Display the written content
    const currentText = contentState.getPlainText(); // Get the plain text from the editor
    setDisplayedData(currentText);
  };

  const toggleBold = () => {
    setEditorState(RichUtils.toggleInlineStyle(editorState, 'BOLD'));
  };

  const toggleItalic = () => {
    setEditorState(RichUtils.toggleInlineStyle(editorState, 'ITALIC'));
  };

  const toggleUnderline = () => {
    setEditorState(RichUtils.toggleInlineStyle(editorState, 'UNDERLINE'));
  };

  const toggleBulletList = () => {
    setEditorState(RichUtils.toggleBlockType(editorState, 'unordered-list-item'));
  };

  return (
    <div className={Styles.richtexteditor_main}>
    <div className={Styles.richtexteditor}>
     
      
      <div className={`richtext-editor`}
><div className={Styles.richtext_header}> <Button onClick={toggleBold} variant="contained" className={Styles.rich_button}>B</Button>
      <Button onClick={toggleItalic} variant="contained" className={Styles.rich_button}>I</Button>
      <Button onClick={toggleUnderline} variant="contained" className={Styles.rich_button}>U</Button>
      <Button onClick={toggleBulletList} variant="contained" className={Styles.rich_button}>List</Button></div>
      <Editor
        editorState={editorState}
        onChange={handleEditorChange}
      />
            <Button onClick={handleSave} className={Styles.richtext_button} variant="contained" color="primary">Save</Button>

      </div>
      
      <div className={Styles.saved_data}>{savedData}</div>

      {/* Display the content of the editor */}
      <div className={Styles.written_content}>
        <h3>Written Content:</h3>
        <p>{displayedData}</p>
      </div>
    </div>
    </div>
  );
};

export default RichTextEditor;
