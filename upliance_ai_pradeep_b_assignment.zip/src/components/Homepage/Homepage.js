import React from "react";
import { useNavigate, Routes, Route, useLocation } from "react-router-dom";
import Navigation from "../Navigation/Navigation"; 
import Counter from "../Counter/Counter";
import UserData from "../UserData/UserData"; 
import RichtextEditor from "../RichtextEditor/RichtextEditor";
import Styles from "./homepage.module.css"; 

function Homepage() {
  const navigate = useNavigate(); 
  const location = useLocation(); 

  const navigationItems = [
    { name: "Counter", path: "/homepage/counter", component: <Counter /> },
    { name: "User Data", path: "/homepage/userdata", component: <UserData /> },
    { name: "Rich Text Editor", path: "/homepage/richtexteditor", component: <RichtextEditor /> },
  ];

  const handleNavigation = (path) => {
    navigate(path); 
  };

  return (
    <div className={Styles.homepage_main}>
      <Navigation />

      <div className={Styles.navigation_bar}>
        {navigationItems.map((item, index) => (
          <button
            key={index}
            onClick={() => handleNavigation(item.path)}
            className={`${Styles.nav_btn} ${location.pathname === item.path ? Styles.nav_btn_selected : ""}`} 
          >
            {item.name}
          </button>
        ))}
      </div>

      <div className={Styles.component_container}>
        <Routes>
          <Route path="/counter" element={<Counter />} />
          <Route path="/userdata" element={<UserData />} />
          <Route path="/richtexteditor" element={<RichtextEditor />} />
        </Routes>
      </div>
    </div>
  );
}

export default Homepage;
