import React, { useState, useEffect } from 'react';
import { TextField, Button, Snackbar, Dialog, DialogActions, DialogContent, DialogTitle } from '@mui/material';
import Styles from "./userData.module.css";
import "./userData.css";
const UserData = () => {
  const [userData, setUserData] = useState({ name: '', address: '', email: '', phone: '' });
  const [unsavedChanges, setUnsavedChanges] = useState(false);
  const [userId, setUserId] = useState('');
  const [openDialog, setOpenDialog] = useState(false);

  useEffect(() => {
    const storedUserData = JSON.parse(localStorage.getItem('userData'));
    if (storedUserData) {
      setUserData(storedUserData);
      setUserId(storedUserData.userId); 
    } else {
      const newUserId = `user-${Math.floor(Math.random() * 10000)}`;
      setUserId(newUserId);
    }

    window.onbeforeunload = () => {
      if (unsavedChanges) {
        return 'You have unsaved changes. Are you sure you want to leave?';
      }
    };
  }, [unsavedChanges]);

  const handleChange = (e) => {
    setUnsavedChanges(true);
    setUserData({
      ...userData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = () => {
    const dataToSave = { ...userData, userId };
    localStorage.setItem('userData', JSON.stringify(dataToSave));
    setUnsavedChanges(false);
    setOpenDialog(true);
  };

  const handleDialogClose = () => {
    setOpenDialog(false);  
  };

  return (
    <div className={Styles.userdata}>
      <TextField
        label="Name"
        name="name"
        value={userData.name}
        onChange={handleChange}
        fullWidth
        className={`${Styles.text_field}`}    
      />
      <TextField
        label="Address"
        name="address"
        value={userData.address}
        onChange={handleChange}
        fullWidth
        className={`${Styles.text_field}`}    
      />
      <TextField
        label="Email"
        name="email"
        value={userData.email}
        onChange={handleChange}
        fullWidth
        className={`${Styles.text_field}`}    
      />
      <TextField
        label="Phone"
        name="phone"
        value={userData.phone}
        onChange={handleChange}
        fullWidth
        className={`${Styles.text_field}`}    
      />
      <Button className={Styles.save_btn} onClick={handleSubmit} variant="contained" color="primary">
        Save
      </Button>
      <Snackbar
        open={unsavedChanges}
        message="You have unsaved changes!"
        autoHideDuration={3000}
      />
      
      <Dialog open={openDialog} onClose={handleDialogClose}>
        <DialogTitle>Data Saved</DialogTitle>
        <DialogContent>
          <p><strong>Name:</strong> {userData.name}</p>
          <p><strong>Address:</strong> {userData.address}</p>
          <p><strong>Email:</strong> {userData.email}</p>
          <p><strong>Phone:</strong> {userData.phone}</p>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDialogClose} color="primary">
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default UserData;
