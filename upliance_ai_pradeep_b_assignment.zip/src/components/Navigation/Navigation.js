import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // For navigation
import Styles from './navigation.module.css';

// Import the components


function Navigation() {
  const [showSettingsPopup, setShowSettingsPopup] = useState(false);

  const navigate = useNavigate(); // Using the hook to navigate

  const handleUserIconClick = () => {
    setShowSettingsPopup(!showSettingsPopup);
  };

  const handleLogout = () => {
    console.log('User logged out.');
    navigate('/'); // Redirect to homepage
  };



  return (
    <div className={Styles.navigation_main}>
      <div className={Styles.organisation_header}>
        <h2>Navigate</h2>

        {/* User Icon */}
        <div onClick={handleUserIconClick} className={Styles.user_icon}>
          {/* Settings Popup */}
          {showSettingsPopup && (
            <div className={Styles.user_modal}>
              <button onClick={handleLogout} className={Styles.logout_btn}>
                Logout
              </button>
            </div>
          )}
        </div>
      </div>

    
    </div>
  );
}

export default Navigation;
