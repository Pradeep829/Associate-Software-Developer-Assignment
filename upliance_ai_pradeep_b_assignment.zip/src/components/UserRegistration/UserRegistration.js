import React, { useState } from 'react';
import Styles from "./userRegistration.module.css";
import { GoogleLogin } from '@react-oauth/google'; // Import GoogleLogin component
import { useNavigate } from 'react-router-dom'; // Import useNavigate for navigation

const UserRegistration = () => {
  const navigate = useNavigate(); 
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isVerified, setIsVerified] = useState(false);
  const [verificationCode, setVerificationCode] = useState('');
  const [isCodeSent, setIsCodeSent] = useState(false);

  const handleEmailVerification = () => {
    if (email) {
      setIsCodeSent(true);
      alert("Verification code sent to email!");
    }
  };

  const handleVerifyCode = () => {
    if (verificationCode === "123456") {
      setIsVerified(true);
    } else {
      alert("Invalid verification code.");
    }
  };

  const handleGoogleLoginSuccess = (response) => {
    console.log("Google login success", response);
    navigate('/homepage');
  };

  const handleGoogleLoginFailure = (error) => {
    console.error("Google login error", error);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // After form submission, navigate to Organisation page
    navigate('/homepage');
  };


  return (
    <div className={Styles.login_main}>
      <div className={ Styles.login}>
        <h2 className={Styles.title}>User Registration</h2>
        <form onSubmit={handleSubmit}>
          <div className={Styles.fields}>
            <label className={Styles.label}>Name</label>
            <input 
              type="text" 
              placeholder="Name" 
              required 
              className={Styles.input}
            />
          </div>
          <div className={Styles.fields}>
            <label className={Styles.label}>Email</label>
            <input 
              type="email" 
              placeholder="Email" 
              value={email} 
              onChange={(e) => setEmail(e.target.value)} 
              required 
              className={Styles.input}
            />
          </div>
          <div className={Styles.fields}>
            <label className={Styles.label}>Password</label>
            <input 
              type="password" 
              placeholder="Password" 
              value={password} 
              onChange={(e) => setPassword(e.target.value)} 
              required 
              className={Styles.input}
            />
          </div>

          {!isVerified ? (
            <div>
              {!isCodeSent && (
                 <button 
                 type="button" 
                 onClick={handleEmailVerification} 
                 className={Styles.button}
               >
                 Verify Email
               </button>
              )}
             
              {isCodeSent && (
                <div>
                  <label className={Styles.label}>Enter Verification Code</label>
                  <input 
                    type="text" 
                    placeholder="Verification Code" 
                    value={verificationCode} 
                    onChange={(e) => setVerificationCode(e.target.value)} 
                    required 
                    className={Styles.input}
                  />
                  <button 
                    type="button" 
                    onClick={handleVerifyCode} 
                    className={Styles.verify_button}
                  >
                    Verify Code
                  </button>
                </div>
              )}
            </div>
          ) : (
            <p className={Styles.verified}>Email Verified! Proceed to next steps.</p>
          )}

          <div className={Styles.submit_button}>
            <button 
              type="submit" 
              className={Styles.button}
            >
              Submit
            </button>
          </div>
        </form>
        
        {/* Google Login Button */}
        <div className={Styles.google_button}>
          <GoogleLogin
            onSuccess={handleGoogleLoginSuccess} 
            onError={handleGoogleLoginFailure}   
          />
        </div>
      </div>
    </div>
  );
};

export default UserRegistration;
