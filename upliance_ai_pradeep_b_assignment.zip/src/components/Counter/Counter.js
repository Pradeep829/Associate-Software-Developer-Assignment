import React, { useState } from 'react';
import { Button, Typography } from '@mui/material';
import { useSpring, animated } from 'react-spring';
import Styles from "./counter.module.css";
 import "./counter.css";
const Counter = () => {
  const [count, setCount] = useState(0);

  const bgColor = useSpring({
    backgroundColor: `rgb(${count * 7}, ${count * 6}, 200)`, 
    config: { tension: 200, friction: 20 },
  });

  return (
    <animated.div style={{ ...bgColor, height: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center' }} className={Styles.counter_main}>
      <div className='counter'>
        <Typography variant="h4">Counter: {count}</Typography>
        <Button onClick={() => setCount(count + 1)} variant="contained" color="primary">Increment</Button>
        <Button onClick={() => setCount(count - 1)} variant="contained" color="secondary">Decrement</Button>
        <Button onClick={() => setCount(0)} variant="contained" color="error">Reset</Button>
      </div>
    </animated.div>
  );
};

export default Counter;
